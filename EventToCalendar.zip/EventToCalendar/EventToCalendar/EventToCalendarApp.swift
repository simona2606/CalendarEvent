//
//  EventToCalendarApp.swift
//  EventToCalendar
//
//  Created by Simona Ettari on 05/12/22.
//

import SwiftUI

@main
struct EventToCalendarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(EventStore.shared)
        }
    }
}
